import sys
import os
import matplotlib
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.patches import Circle
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QHBoxLayout, QVBoxLayout, QPushButton, QWidget,
    QLabel, QLineEdit, QFormLayout
)
from PyQt6.QtGui import QDrag, QPainter, QColor, QPixmap
from PyQt6.QtCore import Qt, QMimeData
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
import numpy as np
from PyQt6.QtOpenGLWidgets import QOpenGLWidget


class ObjLoader:
    def __init__(self, filename):
        self.vertices = []
        self.faces = []
        self.load_obj(filename)

    def load_obj(self, filename):
        with open(filename, "r") as file:
            for line in file:
                if line.startswith("v "):  # Vertex
                    parts = line.split()
                    vertex = (float(parts[1]), float(parts[2]), float(parts[3]))
                    self.vertices.append(vertex)
                elif line.startswith("f "):  # Face
                    parts = line.split()
                    face = [int(idx.split('/')[0]) - 1 for idx in parts[1:]]
                    self.faces.append(face)

    def find_closest_vertex(self, x, y, z):
        """Find the closest vertex to a given point."""
        min_distance = float('inf')
        closest_vertex = None

        for vertex in self.vertices:
            distance = np.sqrt((vertex[0] - x) ** 2 + (vertex[1] - y) ** 2 + (vertex[2] - z) ** 2)
            if distance < min_distance:
                min_distance = distance
                closest_vertex = vertex

        return closest_vertex


class DraggableLight(QLabel):
    def __init__(self, color):
        super().__init__()
        self.color = color
        self.setFixedSize(40, 40)

        pixmap = QPixmap(40, 40)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setBrush(QColor(*color))
        painter.setPen(Qt.GlobalColor.black)
        painter.drawEllipse(0, 0, 40, 40)
        painter.end()
        self.setPixmap(pixmap)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            drag = QDrag(self)
            mime_data = QMimeData()
            mime_data.setText(f"{self.color[0]},{self.color[1]},{self.color[2]}")
            drag.setMimeData(mime_data)

            drag_pixmap = QPixmap(self.size())
            self.render(drag_pixmap)
            drag.setPixmap(drag_pixmap)
            drag.setHotSpot(event.pos())

            drag.exec(Qt.DropAction.MoveAction)


class OpenGLWidget(QOpenGLWidget):
    def __init__(self, obj_path):
        super().__init__()
        self.obj = ObjLoader(obj_path)
        self.lights = []  # Store lights as (x, y, z, color) tuples
        self.zoom = -15.0  # Zoom level
        self.rotation_x = 0  # Rotation angle around the X-axis
        self.rotation_y = 0  # Rotation angle around the Y-axis
        self.pan_x = 0  # Pan offset in the X-axis
        self.pan_y = 0  # Pan offset in the Y-axis
        self.last_mouse_pos = None  # Track the last mouse position for movement

    def initializeGL(self):
        glEnable(GL_DEPTH_TEST)
        glClearColor(0.1, 0.1, 0.1, 1.0)

    def resizeGL(self, width, height):
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(60, width / height, 0.1, 100.0)
        glMatrixMode(GL_MODELVIEW)

    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()

        # Apply panning
        glTranslatef(self.pan_x, self.pan_y, self.zoom)

        # Apply rotation
        glRotatef(self.rotation_x, 1, 0, 0)  # Rotate around X-axis
        glRotatef(self.rotation_y, 0, 1, 0)  # Rotate around Y-axis

        self.draw_grass()
        self.draw_obj()
        self.draw_lights()

    def draw_obj(self):
        glColor3f(1.0, 1.0, 1.0)
        glBegin(GL_TRIANGLES)
        for face in self.obj.faces:
            for vertex_idx in face:
                glVertex3fv(self.obj.vertices[vertex_idx])
        glEnd()

    def draw_grass(self):
        glColor3f(0.0, 0.5, 0.0)
        glBegin(GL_QUADS)
        glVertex3f(-10.0, -1.0, -10.0)
        glVertex3f(10.0, -1.0, -10.0)
        glVertex3f(10.0, -1.0, 10.0)
        glVertex3f(-10.0, -1.0, 10.0)
        glEnd()

    def draw_lights(self):
        for x, y, z, color in self.lights:
            glColor3f(color[0] / 255.0, color[1] / 255.0, color[2] / 255.0)
            glPushMatrix()
            glTranslatef(x, y, z)
            glutSolidSphere(0.2, 20, 20)
            glPopMatrix()

    def mousePressEvent(self, event):
        self.last_mouse_pos = event.position()

    def mouseMoveEvent(self, event):
        if self.last_mouse_pos is None:
            return

        dx = event.position().x() - self.last_mouse_pos.x()
        dy = event.position().y() - self.last_mouse_pos.y()

        if event.buttons() & Qt.MouseButton.LeftButton:  # Left button: Rotate
            self.rotation_x += dy * 0.5
            self.rotation_y += dx * 0.5
        elif event.buttons() & Qt.MouseButton.MiddleButton:  # Middle button: Pan
            self.pan_x += dx * 0.01
            self.pan_y -= dy * 0.01

        self.last_mouse_pos = event.position()
        self.update()

    def mouseReleaseEvent(self, event):
        self.last_mouse_pos = None

    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        self.zoom += delta / 120 * 0.5
        self.update()


class Viewer2DCanvas(QWidget):
    def __init__(self, add_light_callback, obj):
        super().__init__()
        self.figure = Figure(figsize=(4, 4))
        self.canvas = FigureCanvas(self.figure)
        layout = QVBoxLayout()
        layout.addWidget(self.canvas)
        self.setLayout(layout)
        self.ax = None
        self.add_light_callback = add_light_callback
        self.obj = obj
        self.view_mode = "Top"
        self.counter_label = QLabel("Lights: 0")
        self.counter_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.counter_label.setStyleSheet("color: black; background-color: white; font-size: 12px;")
        layout.addWidget(self.counter_label)

    def update_2d_view(self, vertices, lights, view_mode):
        self.figure.clear()
        self.ax = self.figure.add_subplot(111)
        self.ax.set_title(f"{view_mode} View")
        self.view_mode = view_mode

        if view_mode == "Top":
            xs = [v[0] for v in vertices]
            ys = [v[2] for v in vertices]
        elif view_mode == "Front":
            xs = [v[0] for v in vertices]
            ys = [v[1] for v in vertices]
        elif view_mode == "Side":
            xs = [v[2] for v in vertices]
            ys = [v[1] for v in vertices]
        self.ax.scatter(xs, ys, c='blue', s=10, label="Object Vertices")

        for light in lights:
            if view_mode == "Top":
                lx, ly = light[0], light[2]
            elif view_mode == "Front":
                lx, ly = light[0], light[1]
            elif view_mode == "Side":
                lx, ly = light[2], light[1]
            self.ax.add_patch(Circle((lx, ly), 0.2, color=[c / 255.0 for c in light[3]], label="Light"))

        self.ax.set_xlabel("X" if view_mode in ["Top", "Front"] else "Z")
        self.ax.set_ylabel("Y" if view_mode in ["Front", "Side"] else "Z")
        self.ax.legend()
        self.ax.grid(True)

        # Update light counter
        self.counter_label.setText(f"Lights: {len(lights)}")

        self.canvas.mpl_connect('button_press_event', self.handle_click)
        self.canvas.draw()

    def handle_click(self, event):
        if event.inaxes is not None:
            lx, ly = event.xdata, event.ydata
            if self.view_mode == "Top":
                closest_vertex = self.obj.find_closest_vertex(lx, 0, ly)
            elif self.view_mode == "Front":
                closest_vertex = self.obj.find_closest_vertex(lx, ly, 0)
            elif self.view_mode == "Side":
                closest_vertex = self.obj.find_closest_vertex(0, ly, lx)
            if closest_vertex:
                self.add_light_callback(*closest_vertex)


class MainWindow(QMainWindow):
    def __init__(self, obj_path):
        super().__init__()
        self.setWindowTitle("2D/3D Object Viewer")
        self.setGeometry(100, 100, 1400, 800)

        self.obj = ObjLoader(obj_path)
        self.lights = []

        layout = QHBoxLayout()

        # Add 3D Viewer
        self.opengl_widget = OpenGLWidget(obj_path)
        self.opengl_widget.lights = self.lights
        layout.addWidget(self.opengl_widget, stretch=5)

        # Add right-side layout for 2D Viewer and Controls
        right_layout = QVBoxLayout()

        # Add 2D Viewer
        self.viewer_2d = Viewer2DCanvas(self.add_light, self.obj)
        right_layout.addWidget(self.viewer_2d)

        # Add Control Panel
        controls = self.create_controls()
        right_layout.addWidget(controls)

        layout.addLayout(right_layout)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def create_controls(self):
        panel = QVBoxLayout()

        top_view_btn = QPushButton("Top View")
        top_view_btn.clicked.connect(lambda: self.update_2d_view("Top"))
        front_view_btn = QPushButton("Front View")
        front_view_btn.clicked.connect(lambda: self.update_2d_view("Front"))
        side_view_btn = QPushButton("Side View")
        side_view_btn.clicked.connect(lambda: self.update_2d_view("Side"))

        panel.addWidget(top_view_btn)
        panel.addWidget(front_view_btn)
        panel.addWidget(side_view_btn)

        colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
        for color in colors:
            light = DraggableLight(color)
            panel.addWidget(light)

        coord_layout = QFormLayout()
        self.x_input = QLineEdit()
        self.y_input = QLineEdit()
        self.z_input = QLineEdit()
        coord_layout.addRow("X:", self.x_input)
        coord_layout.addRow("Y:", self.y_input)
        coord_layout.addRow("Z:", self.z_input)
        panel.addLayout(coord_layout)

        place_light_btn = QPushButton("Place Light at Coordinates")
        place_light_btn.clicked.connect(self.place_light_from_coords)
        panel.addWidget(place_light_btn)

        control_widget = QWidget()
        control_widget.setLayout(panel)
        return control_widget

    def update_2d_view(self, view_mode):
        self.viewer_2d.update_2d_view(self.obj.vertices, self.lights, view_mode)

    def add_light(self, x, y, z, color=(255, 255, 0)):
        self.lights.append((x, y, z, color))
        self.opengl_widget.update()
        self.viewer_2d.update_2d_view(self.obj.vertices, self.lights, self.viewer_2d.view_mode)

    def place_light_from_coords(self):
        try:
            x = float(self.x_input.text())
            y = float(self.y_input.text())
            z = float(self.z_input.text())
            closest_vertex = self.obj.find_closest_vertex(x, y, z)
            if closest_vertex:
                self.add_light(*closest_vertex)
        except ValueError:
            print("Invalid coordinates entered!")


if __name__ == "__main__":
    app = QApplication(sys.argv)

    obj_path = "/Users/raneemcorbin/Desktop/cone.obj"
    if not os.path.exists(obj_path):
        print("Error: OBJ file not found.")
        sys.exit(1)

    window = MainWindow(obj_path)
    window.show()
    sys.exit(app.exec())
